package com.valuehunter.app;
import android.app.*; import android.os.*; import android.widget.*; import java.io.*; import java.net.*; import java.util.concurrent.*;
public class MainActivity extends Activity {
 TextView status,results; Button scan; ExecutorService worker=Executors.newSingleThreadExecutor(); Handler main=new Handler(Looper.getMainLooper());
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout x=new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); x.setPadding(32,32,32,32);
 TextView t=new TextView(this); t.setText("VALUE HUNTER\nشکارچی فرصت‌های مجاز"); t.setTextSize(22); x.addView(t);
 status=new TextView(this); status.setText("\nآماده"); status.setTextSize(16); x.addView(status);
 scan=new Button(this); scan.setText("شروع اسکن"); x.addView(scan);
 results=new TextView(this); results.setText("\nنتیجه‌ها اینجا می‌آیند.\nفقط داده‌های عمومی بررسی می‌شوند."); results.setTextSize(15); x.addView(results); setContentView(x); scan.setOnClickListener(v->runScan());}
 void runScan(){scan.setEnabled(false);status.setText("\nدر حال اسکن...");worker.execute(()->{String j=fetch();main.post(()->{scan.setEnabled(true);if(j==null){status.setText("\nاتصال ناموفق");results.setText("سرویس عمومی در دسترس نبود.");}else{status.setText("\nاسکن انجام شد");results.setText("موارد عمومی پیدا شده:\n\n"+urls(j));}});});}
 String fetch(){try{HttpURLConnection c=(HttpURLConnection)new URL("https://api.github.com/search/issues?q=bounty+is%3Aopen&per_page=10").openConnection();c.setConnectTimeout(10000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/vnd.github+json");BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);r.close();return s.toString();}catch(Exception e){return null;}}
 String urls(String j){StringBuilder s=new StringBuilder();String[] a=j.split("\"html_url\":\"");int n=0;for(int i=1;i<a.length&&n<10;i++){String u=a[i].split("\"")[0];s.append(++n).append(". ").append(u).append("\n");}return n==0?"موردی پیدا نشد.":s.toString();}
 protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}